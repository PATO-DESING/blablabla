package com.estacionamiento_smartpark.smart_park;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartParkApplicationTests {

	@Test
	void contextLoads() {
	}

}
